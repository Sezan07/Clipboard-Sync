package com.example.clipboardsyncapp

import android.app.Service
import android.content.*
import android.os.IBinder
import android.util.Log
import android.content.ClipboardManager
import android.content.ClipData
import okhttp3.*

@Deprecated("Replaced by ClipboardAccessibilityService")
class ClipboardSyncService : Service() {

    private lateinit var clipboard: ClipboardManager
    private var lastSentText: String = ""
    private var webSocket: WebSocket? = null

    private val PREFS_NAME = "clipboard_prefs"
    private val SESSION_KEY = "session_id"
    private var sessionId: String? = null

    override fun onCreate() {
        super.onCreate()

        // Load saved session ID
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        sessionId = prefs.getString(SESSION_KEY, null)

        // Abort if session ID is missing
        if (sessionId.isNullOrBlank()) {
            Log.e("ClipboardSync", "No session ID found. Service not started.")
            stopSelf()
            return
        }

        clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        clipboard.addPrimaryClipChangedListener {
            val clip = clipboard.primaryClip
            val item = clip?.getItemAt(0)
            val text = item?.text?.toString()

            if (!text.isNullOrBlank() && text != lastSentText) {
                lastSentText = text
                webSocket?.send(text)
                Log.d("ClipboardSync", "Sent: $text")
            }
        }

        initWebSocket()
    }

    private fun initWebSocket() {
        val request = Request.Builder()
            .url("wss://clipboard-synchronization.onrender.com/ws/$sessionId")
            .build()

        val client = OkHttpClient()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("ClipboardSync", "WebSocket connected")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d("ClipboardSync", "Received: $text")
                if (text != lastSentText) {
                    lastSentText = text
                    val clip = ClipData.newPlainText("clipboard", text)
                    clipboard.setPrimaryClip(clip)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.w("ClipboardSync", "WebSocket closing: $reason")
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("ClipboardSync", "WebSocket error: ${t.localizedMessage}")
            }
        })
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// This service is now deprecated and replaced by ClipboardAccessibilityService.
// All clipboard sync logic is handled by the accessibility service for Android 10+ compatibility.
// The code is intentionally left empty/disabled.
//
// Optionally, you may delete this file if not needed for legacy support.
