package com.example.clipboardsyncapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*

class MainActivity : AppCompatActivity() {

    private lateinit var clipboardManager: ClipboardManager
    private lateinit var clipboardInput: EditText
    private lateinit var sendButton: Button
    private lateinit var statusText: TextView
    private lateinit var sessionInput: EditText
    private lateinit var startSyncButton: Button
    private lateinit var resetSessionButton: Button

    private val client = OkHttpClient()
    private var webSocket: WebSocket? = null
    private var sessionId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clipboardInput = findViewById(R.id.clipboardInput)
        sendButton = findViewById(R.id.sendButton)
        statusText = findViewById(R.id.statusText)
        sessionInput = findViewById(R.id.sessionInput)
        startSyncButton = findViewById(R.id.startSyncButton)
        resetSessionButton = findViewById(R.id.resetSessionButton)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        val prefs = getSharedPreferences("clipboard_prefs", MODE_PRIVATE)
        val savedSession = prefs.getString("session_id", null)

        if (savedSession != null) {
            sessionId = savedSession
            sessionInput.setText(sessionId)
            sessionInput.isEnabled = false
            startSyncButton.isEnabled = false
            startClipboardSync()
        }

        startSyncButton.setOnClickListener {
            val input = sessionInput.text.toString().trim()
            if (input.isNotEmpty()) {
                sessionId = input
                prefs.edit().putString("session_id", sessionId).apply()
                sessionInput.isEnabled = false
                startSyncButton.isEnabled = false
                startClipboardSync()
            } else {
                statusText.text = "❌ Please enter a valid session ID"
            }
        }

        resetSessionButton.setOnClickListener {
            prefs.edit().remove("session_id").apply()
            sessionInput.setText("")
            sessionInput.isEnabled = true
            startSyncButton.isEnabled = true
            statusText.text = "🔁 Session reset. Enter new session ID to continue."
        }

        sendButton.setOnClickListener {
            val data = clipboardInput.text.toString()
            if (data.isNotBlank()) {
                webSocket?.send(data)
                statusText.text = "📤 Sent: \"$data\""
            }
        }
    }

    private fun startClipboardSync() {
        startService(Intent(this, ClipboardSyncService::class.java))

        val request = Request.Builder()
            .url("wss://clipboard-synchronization.onrender.com/ws/$sessionId")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread {
                    statusText.text = "✅ Connected to session: $sessionId"
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runOnUiThread {
                    clipboardInput.setText(text)
                    clipboardManager.setPrimaryClip(ClipData.newPlainText("Clipboard", text))
                    statusText.text = "📥 Received from server"
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread {
                    statusText.text = "❌ Connection failed: ${t.localizedMessage}"
                }
            }
        })
    }
}
