package com.example.clipboardsyncapp

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper
import okhttp3.*

class ClipboardAccessibilityService : AccessibilityService() {
    private lateinit var clipboard: ClipboardManager
    private var lastSentText: String = ""
    private var lastSelectedText: String? = null
    private var webSocket: WebSocket? = null
    private val PREFS_NAME = "clipboard_prefs"
    private val SESSION_KEY = "session_id"
    private var sessionId: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        sessionId = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(SESSION_KEY, null)
        if (sessionId.isNullOrBlank()) {
            Log.e("ClipboardSync", "No session ID; service will not start.")
            return
        }
        val request = Request.Builder()
            .url("wss://clipboard-synchronization.onrender.com/ws/$sessionId")
            .build()
        val client = OkHttpClient()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d("ClipboardSync", "WebSocket connected")
            }
            override fun onMessage(ws: WebSocket, text: String) {
                Log.d("ClipboardSync", "Received: $text")
                if (text != lastSentText) {
                    lastSentText = text
                    val clip = ClipData.newPlainText("clipboard", text)
                    clipboard.setPrimaryClip(clip)
                    Log.d("ClipboardSync", "Clipboard updated with received text")
                }
            }
            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                Log.w("ClipboardSync", "WebSocket closing: $reason")
                ws.close(1000, null)
            }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e("ClipboardSync", "WebSocket error: ${t.localizedMessage}")
            }
        })
        Log.d("ClipboardSync", "ClipboardAccessibilityService started for session $sessionId")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> {
                val source = event.source
                if (source != null && source.text != null) {
                    val start = source.textSelectionStart
                    val end = source.textSelectionEnd
                    if (start >= 0 && end > start && end <= source.text.length) {
                        val selectedText = source.text.subSequence(start, end).toString()
                        lastSelectedText = selectedText
                        Log.d("ClipboardSync", "Selected text captured: $selectedText")
                    }
                }
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val texts = event.text
                if (texts != null) {
                    for (text in texts) {
                        if (text != null && text.toString().equals("Copy", ignoreCase = true)) {
                            Log.d("ClipboardSync", "'Copy' clicked detected via event.text")
                            if (!lastSelectedText.isNullOrBlank() && lastSelectedText != lastSentText) {
                                lastSentText = lastSelectedText!!
                                webSocket?.send(lastSelectedText!!)
                                Log.d("ClipboardSync", "Sent (via copy click): $lastSelectedText")
                                lastSelectedText = null
                            }
                        }
                    }
                }
            }
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> {
                // User long-pressed text, possibly to bring up copy menu
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Optionally handle fallback for custom UIs or context menu appearance
            }
        }
    }

    override fun onInterrupt() {
        // Required override; do nothing
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocket?.close(1000, null)
        Log.d("ClipboardSync", "AccessibilityService destroyed")
    }
}
